void load_config(char configPath[255], char supportedInput[255], void* p);
