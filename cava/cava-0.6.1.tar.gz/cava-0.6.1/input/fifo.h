//header files for fifo, part of cava
void* input_fifo(void* data);
