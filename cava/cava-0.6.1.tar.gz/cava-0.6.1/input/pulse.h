//header file for pulse, part of cava.

void* input_pulse(void* data);
void getPulseDefaultSink();

