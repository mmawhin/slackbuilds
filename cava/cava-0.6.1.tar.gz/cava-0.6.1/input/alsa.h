//header file for alsa, part of cava.

void* input_alsa(void* data);

